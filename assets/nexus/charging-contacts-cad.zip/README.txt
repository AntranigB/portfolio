Nexus charging-contact working CAD exports, Fall 2025.
These are dated design iterations, not a certified or final production design.
Fusion 360: .f3d / .f3z. Mesh exports: .stl.
Final installation and test status: [MORE INFO NEEDED].
